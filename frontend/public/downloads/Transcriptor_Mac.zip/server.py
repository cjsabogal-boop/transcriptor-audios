import os
import sys
import threading
import multiprocessing as mp
import subprocess
import time
try:
    import torch
    import whisper
    # Desactivar MPS a nivel de backend para evitar crasheos de SparseMPS en Mac
    if torch is not None:
        torch.set_num_threads(4)
        if hasattr(torch.backends, "mps"):
            # En modelos base/tiny, CPU es más que suficiente y 100% estable.
            # No usamos mps.is_available = lambda: False porque es muy invasivo,
            # pero forzaremos 'cpu' en la carga del modelo.
            pass
except ImportError:
    torch = None
    whisper = None
from flask import Flask, jsonify, request
try:
    from flask_cors import CORS
except ImportError:
    CORS = None
from werkzeug.utils import secure_filename

# Configuración GLOBAL para estabilidad
os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"
# Algunos drivers de Mac tienen fugas si se usa MPS con procesos hijos
os.environ["PYTORCH_MPS_HIGH_WATERMARK_RATIO"] = "0.0" 

app = Flask(__name__)

# Placeholder para el estado compartido
STATE = None
manager = None

def get_state():
    """Retorna el estado compartido. En procesos hijos se usa el pasado por argumento."""
    global STATE
    if STATE is None:
        # Fallback para evitar NameError en hilos/procesos que no recibieron el estado
        return {}
    return STATE

# Habilitar CORS para permitir peticiones del frontend en puertos diferentes
if CORS:
    CORS(app, resources={r"/api/*": {"origins": "*"}})
else:
    # Fallback manual CORS si flask-cors no está instalado
    @app.after_request
    def add_cors_headers(response):
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, DELETE, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        return response

AUDIO_DIR = os.path.expanduser("~/Documents/Audios")
os.makedirs(AUDIO_DIR, exist_ok=True)
app.config['UPLOAD_FOLDER'] = AUDIO_DIR
os.environ["PATH"] += os.pathsep + "/opt/homebrew/bin" + os.pathsep + "/usr/local/bin" + os.pathsep + os.path.expanduser("~/.local/bin")
SERVER_START_TIME = time.time()

# ── Singleton del modelo Whisper ──
# Forzamos CPU en macOS para evitar errores de SparseMPS (aten::_sparse_coo_tensor)
# que son comunes en procesadores M1/M2/M3 incluso con fallback activado.
WHISPER_MODELS = {}
WHISPER_DEVICE = "cpu"

def cargar_modelo(model_size="base"):
    global WHISPER_MODELS, WHISPER_DEVICE
    if model_size in WHISPER_MODELS:
        return WHISPER_MODELS[model_size]
    
    # Aunque MPS sea posible, se prefiere CPU por estabilidad en modelos base/tiny
    # Si el usuario tiene una GPU potente (NVIDIA), se podría usar cuda.
    WHISPER_DEVICE = "cpu"
    if torch is not None:
        if torch.cuda.is_available():
            WHISPER_DEVICE = "cuda"
        # En Mac, se podría usar MPS, pero causa crasheos esporádicos en Whisper.
        # Forzar CPU es mucho más estable y suficientemente rápido para 'base'/'tiny'.
        torch.set_num_threads(8)
        
    print(f"📦 Cargando modelo Whisper '{model_size}' en {WHISPER_DEVICE.upper()} (modo alta estabilidad)...")
    WHISPER_MODELS[model_size] = whisper.load_model(model_size, device=WHISPER_DEVICE)
    print(f"✅ Modelo '{model_size}' cargado y listo para procesar.")
    return WHISPER_MODELS[model_size]

def obtener_duracion_audio(ruta):
    """Obtiene la duración en segundos del audio usando ffprobe."""
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'quiet', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', ruta],
            capture_output=True, text=True, timeout=10
        )
        return float(result.stdout.strip())
    except Exception:
        return None

def preconvertir_audio(ruta_entrada):
    """Pre-convierte el audio de forma AGRESIVA para procesar más rápido.
    - 16kHz mono (nativo de Whisper)
    - Lowpass filter 8kHz (Nyquist, elimina ruido innecesario)
    - Normalización de volumen
    - Formato WAV 16-bit
    """
    ruta_opt = ruta_entrada.rsplit('.', 1)[0] + "_optimized.wav"
    try:
        subprocess.run(
            ['ffmpeg', '-y', '-nostdin', '-threads', '4', '-i', ruta_entrada,
             '-ac', '1', '-ar', '16000',
             '-af', 'lowpass=f=7500,volume=1.5',
             '-c:a', 'pcm_s16le',
             '-loglevel', 'error', ruta_opt],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, timeout=300
        )
        # Verificar que el archivo se creó y tiene contenido
        if os.path.exists(ruta_opt) and os.path.getsize(ruta_opt) > 0:
            size_orig = os.path.getsize(ruta_entrada) / (1024*1024)
            size_opt = os.path.getsize(ruta_opt) / (1024*1024)
            print(f"🗜️ Audio preprocesado: {size_orig:.1f}MB → {size_opt:.1f}MB")
            return ruta_opt
        return ruta_entrada
    except Exception as e:
        print(f"⚠️ Pre-conversión falló, usando archivo original: {e}")
        return ruta_entrada

def limpiar_temporales():
    """Limpia archivos temporales que quedaron de sesiones anteriores."""
    try:
        for f in os.listdir(AUDIO_DIR):
            if f.endswith('_temp16k.wav') or f.endswith('_temp.wav') or f.endswith('_optimized.ogg') or f.endswith('_optimized.wav'):
                ruta = os.path.join(AUDIO_DIR, f)
                os.remove(ruta)
                print(f"🧹 Limpiado temporal: {f}")
    except Exception:
        pass


def check_dependencies():
    return torch is None or whisper is None

@app.route("/")
def index():
    return jsonify({"status": "Servidor Local Transcriptor está OK. Transcriptor By Carlos Sabogal."})

def subrutina_instalar(estado):
    estado["is_installing"] = True
    estado["status_text"] = "Instalando dependencias core de macOS... (puede pedir contraseña en consola)"
    
    try:
        subprocess.run(['bash', '-lc', 'if ! command -v brew &> /dev/null; then NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"; fi'], check=False)
        estado["status_text"] = "Configurando herramientas de procesamiento de audio de fondo..."
        subprocess.run(['bash', '-lc', 'brew install ffmpeg'], check=False)
        estado["status_text"] = "Vinculando Módulos de Inteligencia Artificial..."
        subprocess.run(['bash', '-lc', 'python3 -m pip install openai-whisper torch ffmpeg-python flask-cors deep-translator edge-tts --break-system-packages || python3 -m pip install openai-whisper torch ffmpeg-python flask-cors deep-translator edge-tts'], check=False)

        estado["status_text"] = "¡Instalación lista! Refrescando la plataforma..."
        time.sleep(4)
    except Exception as e:
        estado["status_text"] = f"Error instalando: {str(e)}"
        time.sleep(10)
    
    estado["is_installing"] = False

@app.route("/api/install", methods=["POST"])
def install_system():
    if STATE["is_installing"]:
        return jsonify({"success": False})
    p = mp.Process(target=subrutina_instalar, args=(STATE,))
    p.start()
    return jsonify({"success": True})

@app.route("/api/status")
def status():
    return jsonify(dict(STATE or {}))

@app.route("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "uptime": round(time.time() - SERVER_START_TIME),
        "needs_install": check_dependencies(),
        "is_processing": STATE.get("is_processing", False) if STATE else False
    })

@app.route("/api/audios")
def get_audios():
    audios = []
    try:
        import json
        
        # Usamos los .txt como base de iteración (porque siempre se crea el backup)
        text_files = [f for f in os.listdir(AUDIO_DIR) if f.lower().endswith('.txt') and f != "logs_sistema.txt"]
        
        for txt in text_files:
            bname = os.path.splitext(txt)[0]
            txt_path = os.path.join(AUDIO_DIR, txt)
            json_path = os.path.join(AUDIO_DIR, bname + ".json")
            
            fecha_mod = os.path.getmtime(txt_path)
            
            # Intentar leer el JSON dual primero
            if os.path.exists(json_path):
                with open(json_path, 'r', encoding='utf-8') as fj:
                    data = json.load(fj)
                    text_es = data.get("text_es", "")
                    text_en = data.get("text_en", "")
                    size_bytes = len(text_es.encode('utf-8')) + len(text_en.encode('utf-8'))
            else:
                # Si es un archivo antiguo que solo tiene TXT
                with open(txt_path, 'r', encoding='utf-8') as f:
                    text_es = f.read()
                    text_en = ""
                    size_bytes = len(text_es.encode('utf-8'))
            
            audios.append({
                "title": bname, 
                "text_es": text_es,
                "text_en": text_en,
                "date": fecha_mod,
                "size": size_bytes
            })
            
        audios.sort(key=lambda x: x['date'], reverse=True)
            
    except Exception as e:
        print(f"Error reading audios: {e}")
        
    return jsonify(audios)

@app.route("/api/audios/<title>", methods=["DELETE", "OPTIONS"])
def delete_audio(title):
    """Elimina una transcripción (JSON + TXT + audio original si existe)."""
    if request.method == "OPTIONS":
        return jsonify({"ok": True})
    
    import json
    deleted = []
    errors = []
    
    # Limpiar el título para prevenir path traversal
    safe_title = title.replace("/", "").replace("..", "").replace("\\", "")
    
    for ext in ['.json', '.txt', '.mp3', '.wav', '.m4a']:
        filepath = os.path.join(AUDIO_DIR, safe_title + ext)
        if os.path.exists(filepath):
            try:
                os.remove(filepath)
                deleted.append(safe_title + ext)
            except Exception as e:
                errors.append(f"No se pudo borrar {safe_title + ext}: {str(e)}")
    
    if deleted:
        return jsonify({"success": True, "deleted": deleted, "errors": errors})
    else:
        return jsonify({"success": False, "msg": "No se encontraron archivos para ese título."}), 404

@app.route("/api/upload", methods=["POST"])
def upload_file():
    if STATE and STATE.get("is_processing"):
        return jsonify({"success": False, "msg": "Ya hay una transcripción en proceso. Espera a que termine."})
        
    if 'audiofile' not in request.files:
        return jsonify({"success": False, "msg": "No se envió audio"})
    
    file = request.files['audiofile']
    if file.filename == '':
        return jsonify({"success": False, "msg": "Archivo vacío"})
    
    filename = secure_filename(file.filename)
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(save_path)
    
    p = mp.Process(target=proceso_fondo, args=(save_path, filename, STATE))
    p.start()
    
    return jsonify({"success": True})

def estimador_progreso_visual(filepath, estado, duracion_seg=None):
    """Estimador de progreso con cálculo de tiempo restante real.
    Fase única: transcripción (5-98%), salta a 100% al completar.
    """
    import math
    try:
        size_mb = os.path.getsize(filepath) / (1024 * 1024)
        # Elegir modelo según tamaño
        model_name = "tiny" if size_mb > 30 else "base"
        
        # Whisper procesa muchísimo más rápido en MPS (M1/M2/M3)
        if duracion_seg and duracion_seg > 0:
            factor_duracion = 0.015 if model_name == "tiny" else 0.035
            tiempo_estimado = max(duracion_seg * factor_duracion, 5.0)
        else:
            factor_por_mb = 0.15 if model_name == "tiny" else 0.35
            tiempo_estimado = max(size_mb * factor_por_mb, 5.0)
        
        inicio = time.time()
        
        while estado["is_processing"]:
            time.sleep(1.0)
            if not estado["is_processing"]:
                return
            
            elapsed = time.time() - inicio
            
            # Fase única: Transcripción
            # Para evitar que se quede pegado, usamos un enfoque asintótico si se pasa del tiempo
            if elapsed <= tiempo_estimado:
                progreso_fase = (elapsed / tiempo_estimado) * 0.90
            else:
                extra = elapsed - tiempo_estimado
                progreso_fase = 0.90 + (0.09 * (1.0 - math.exp(-extra / 30.0)))
                
            progreso_actual = 5.0 + (progreso_fase * 90.0)  # 5 -> 95 (hasta un poco más)
            progreso_actual = min(98.0, progreso_actual)
            estado["progress_percent"] = progreso_actual
            
            # Calcular tiempo restante
            if elapsed < tiempo_estimado:
                remaining = max(0, tiempo_estimado - elapsed)
                if remaining > 60:
                    mins = int(remaining // 60)
                    segs = int(remaining % 60)
                    time_str = f"~{mins}m {segs}s restantes estimados"
                else:
                    time_str = f"~{int(remaining)}s restantes estimados"
            else:
                time_str = "Finalizando transcripción..."
            
            nombre_archivo = estado.get("current_filename", "archivo")
            estado["status_text"] = f"Transcribiendo: '{nombre_archivo}' con Inteligencia Artificial...\n{time_str}"
            
    except Exception as e:
        print(f"Error en el estimador: {e}")

def proceso_fondo(ruta_audio, filename, estado):
    import traceback
    def log(msg):
        with open("child_debug.log", "a") as f: f.write(msg + "\n")
        
    with open("child_debug.log", "w") as f: f.write("Child process started\n")
    try:
        estado["is_processing"] = True
        estado["completed"] = False
        estado["error"] = False
        estado["progress_percent"] = 5.0
        estado["current_filename"] = filename
        estado["status_text"] = "Preparando el archivo de audio..."
        log("State initialized")
        
        # Detectar duración real del audio para mejor estimación
        duracion = obtener_duracion_audio(ruta_audio)
        log(f"Audio duration: {duracion}s" if duracion else "Duration unknown")
        
        # Arrancar el estimador de barra de progreso
        log("Starting thread")
        t_estimador = threading.Thread(target=estimador_progreso_visual, args=(ruta_audio, estado, duracion), daemon=True)
        t_estimador.start()
        log("Thread started")
        
        ruta_wav_temp = None
        try:
            base = os.path.splitext(filename)[0]
            log("Base extracted")
            
            # Paso 1: Pre-convertir audio a WAV mono 16kHz
            estado["status_text"] = "Optimizing audio format..."
            log("State updated, preconverting...")
            ruta_procesable = preconvertir_audio(ruta_audio)
            log("Preconvert success")
            if ruta_procesable != ruta_audio:
                ruta_wav_temp = ruta_procesable
            
            # Elegir modelo según tamaño del archivo
            size_mb = os.path.getsize(ruta_audio) / (1024 * 1024)
            model_size = "tiny" if size_mb > 30 else "base"
            log(f"File size: {size_mb:.1f}MB → using model '{model_size}'")
            
            log("Loading model...")
            modelo = cargar_modelo(model_size)
            log(f"Model '{model_size}' loaded. Transcribing English audio...")
            
            # Transcripción en inglés
            estado["status_text"] = "Transcribiendo original (Paso 1/2)..."
            resultado_en = modelo.transcribe(
                ruta_procesable,
                # Quitamos language="es" para que asuma el idioma original (probablemente inglés)
                # o forzamos en, pero mejor dejar que Whisper detecte o forzar "en".
                # El usuario pide "después de la transcripción en inglés"
                language="en",
                fp16=False,
                condition_on_previous_text=False,
                no_speech_threshold=0.6,
            )
            texto_en = resultado_en["text"].strip()
            log("Transcripcion en inglés completada.")

            # Traducción a español
            estado["status_text"] = "Traduciendo a español (Paso 2/2)..."
            from deep_translator import GoogleTranslator
            tr = GoogleTranslator(source='auto', target='es')

            # deep-translator tiene limite de chars, dividimos por oraciones con max 4000
            texto_es_parts = []
            curr = ""
            for sentence in texto_en.replace('\n', ' ').split('. '):
                if len(curr) + len(sentence) < 4000:
                    curr += sentence + ". "
                else:
                    if curr.strip():
                        try:
                            texto_es_parts.append(tr.translate(curr.strip()))
                        except Exception as e:
                            log(f"Err obj: {e}")
                            texto_es_parts.append(curr)
                    curr = sentence + ". "
            if curr.strip():
                try:
                    texto_es_parts.append(tr.translate(curr.strip()))
                except Exception as e:
                    log(f"Err obj final part: {e}")
                    texto_es_parts.append(curr)

            texto_es = " ".join(texto_es_parts).strip()
            log("Traduccion a español completada. Guardando...")

            # Guardar resultado
            import json
            ruta_json = os.path.join(AUDIO_DIR, base + ".json")
            with open(ruta_json, 'w', encoding='utf-8') as f:
                json.dump({
                    "text_es": texto_es,
                    "text_en": texto_en
                }, f, ensure_ascii=False, indent=2)

            ruta_txt = os.path.join(AUDIO_DIR, base + ".txt")
            with open(ruta_txt, 'w', encoding='utf-8') as f:
                f.write(texto_es)

            estado["progress_percent"] = 100.0
            estado["status_text"] = "¡Transcripción y Traducción completadas!"
            log("Saved dual language JSON and backup TXT.")
                    
        except Exception as e:
            estado["status_text"] = f"❌ Error al procesar: {str(e)}"
            estado["progress_percent"] = 0.0
            estado["error"] = True
            log("ERROR: " + str(e))
        finally:
            log("Cleaning up...")
            if ruta_wav_temp and os.path.exists(ruta_wav_temp):
                try:
                    os.remove(ruta_wav_temp)
                except:
                    pass
        
        estado["is_processing"] = False
        if not estado["error"]:
            estado["status_text"] = "✅ ¡Transcripción exitosa! Cargando resultado..."
            estado["completed"] = True
        log("Done gracefully.")
            
    except Exception as e:
        log("Fatal Error:\n" + traceback.format_exc())
        estado["is_processing"] = False
        estado["error"] = True

@app.route("/api/audios/<title>/save", methods=["POST", "OPTIONS"])
def save_audio(title):
    if request.method == "OPTIONS":
        return jsonify({"ok": True})
    data = request.json
    text_es = data.get("text_es", "")
    safe_title = title.replace("/", "").replace("..", "").replace("\\", "")
    json_path = os.path.join(AUDIO_DIR, safe_title + ".json")
    import json
    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                jdata = json.load(f)
            jdata["text_es"] = text_es
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(jdata, f, ensure_ascii=False, indent=2)
            
            # Actualizar el backup TXT
            txt_path = os.path.join(AUDIO_DIR, safe_title + ".txt")
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write(text_es)
            return jsonify({"success": True})
        except Exception as e:
            return jsonify({"success": False, "msg": str(e)}), 500
    return jsonify({"success": False, "msg": "Archivo no encontrado"}), 404

@app.route("/api/audios/<title>/tts", methods=["POST", "OPTIONS"])
def generate_tts(title):
    if request.method == "OPTIONS":
        return jsonify({"ok": True})
    data = request.json
    text_es = data.get("text_es", "")
    if not text_es:
        return jsonify({"success": False, "msg": "No hay texto para hablar"}), 400
        
    safe_title = title.replace("/", "").replace("..", "").replace("\\", "")
    output_mp3 = os.path.join(AUDIO_DIR, safe_title + "_audio_es.mp3")
    
    # ── Procesar texto para pausas naturales ──
    import re
    # Agregar pausas más largas después de punto, cierre de ?, !, y dos puntos
    processed = text_es.strip()
    # Pausa larga (~600ms) después de . ? ! 
    processed = re.sub(r'([.!?])\s+', r'\1 ... ', processed)
    # Pausa media (~300ms) después de , ; : 
    processed = re.sub(r'([,;:])\s+', r'\1 .. ', processed)
    # Pausa entre párrafos
    processed = re.sub(r'\n+', ' ... ... ', processed)
    
    # edge-tts es asíncrono
    import edge_tts
    import asyncio
    
    async def _crear_audio():
        # Voz masculina natural de Colombia, velocidad reducida 15%
        communicate = edge_tts.Communicate(
            processed,
            "es-CO-GonzaloNeural",
            rate="-15%",      # más lento y pausado
            pitch="-5Hz"      # tono ligeramente más grave = más natural
        )
        await communicate.save(output_mp3)
        
    try:
        asyncio.run(_crear_audio())
        return jsonify({"success": True, "download_url": f"/api/download_tts/{safe_title}_audio_es.mp3"})
    except Exception as e:
        return jsonify({"success": False, "msg": str(e)}), 500

@app.route("/api/download_tts/<filename>")
def download_tts_file(filename):
    from flask import send_from_directory
    safe_from = filename.replace("/", "").replace("..", "").replace("\\", "")
    return send_from_directory(AUDIO_DIR, safe_from, as_attachment=True)

if __name__ == "__main__":
    # ═══════════════════════════════════════════════════════════════
    # INICIALIZACIÓN DE ESTADO (MANAGER)
    # ═══════════════════════════════════════════════════════════════
    try:
        # En macOS 'spawn' es el único método seguro, pero requiere
        # que el código esté dentro de __main__
        if mp.get_start_method(allow_none=True) != 'spawn':
            mp.set_start_method('spawn', force=True)
    except RuntimeError:
        pass

    manager = mp.Manager()
    STATE = manager.dict({
        "is_processing": False,
        "status_text": "Sube un archivo de audio para comenzar a transcribir.",
        "is_installing": False,
        "progress_percent": 0.0,
        "completed": False,
        "error": False,
        "current_filename": ""
    })

    # Limpiar temporales de sesiones anteriores al arrancar
    limpiar_temporales()
    print("🚀 Servidor local listo en http://127.0.0.1:5111")
    # threaded=True permite manejar peticiones de health/status mientras se procesa
    app.run(host="127.0.0.1", port=5111, debug=False, threaded=True)
